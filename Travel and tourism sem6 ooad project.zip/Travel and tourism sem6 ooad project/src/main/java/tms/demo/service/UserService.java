package tms.demo.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
    // Your service methods go here
}
