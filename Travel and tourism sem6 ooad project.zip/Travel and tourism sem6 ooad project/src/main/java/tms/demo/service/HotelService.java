package tms.demo.service;

import tms.demo.model.Hotel;
import java.util.List;

public interface HotelService {
    List<Hotel> getAllHotels();
}
