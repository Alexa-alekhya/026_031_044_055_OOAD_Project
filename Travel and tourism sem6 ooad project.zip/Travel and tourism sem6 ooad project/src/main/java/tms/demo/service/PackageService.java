package tms.demo.service;

import java.util.List;

import tms.demo.model.Package;

public interface PackageService {

    List<Package> getAllPackages();
}
