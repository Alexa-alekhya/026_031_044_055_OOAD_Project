// package tms.demo.model;

// import javax.persistence.Entity;
// import javax.persistence.GeneratedValue;
// import javax.persistence.GenerationType;
// import javax.persistence.Id;

// @Entity
// public class BookingDetails {

// @Id
// @GeneratedValue(strategy = GenerationType.IDENTITY)
// private Long id;

// private String packageName;
// private int numberOfPeople;
// private String name;
// private int age;
// private String gender;
// private String location;

// // Constructors
// public BookingDetails() {
// // Default constructor
// }

// public BookingDetails(String packageName, int numberOfPeople, String name,
// int age, String gender,
// String location) {
// this.packageName = packageName;
// this.numberOfPeople = numberOfPeople;
// this.name = name;
// this.age = age;
// this.gender = gender;
// this.location = location;
// }

// // Getters and setters
// public Long getId() {
// return id;
// }

// public void setId(Long id) {
// this.id = id;
// }

// public String getPackageName() {
// return packageName;
// }

// public void setPackageName(String packageName) {
// this.packageName = packageName;
// }

// public int getNumberOfPeople() {
// return numberOfPeople;
// }

// public void setNumberOfPeople(int numberOfPeople) {
// this.numberOfPeople = numberOfPeople;
// }

// public String getName() {
// return name;
// }

// public void setName(String name) {
// this.name = name;
// }

// public int getAge() {
// return age;
// }

// public void setAge(int age) {
// this.age = age;
// }

// public String getGender() {
// return gender;
// }

// public void setGender(String gender) {
// this.gender = gender;
// }

// public String getLocation() {
// return location;
// }

// public void setLocation(String location) {
// this.location = location;
// }
// }
